import joblib
import json
import numpy as np

def model_fn(model_dir):
    model = joblib.load(f"{model_dir}/customer_segmentation_model.pkl")
    return model

def input_fn(request_body, request_content_type):
    return np.array(json.loads(request_body))

def predict_fn(input_data, model):
    X_scaled = model['scaler'].transform(input_data)
    preds = model['kmeans_model'].predict(X_scaled)
    return preds.tolist()

def output_fn(prediction, response_content_type):
    return json.dumps(prediction)
